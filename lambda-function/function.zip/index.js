const fetch = require('node-fetch');

exports.handler = async (event) => {
    const API_KEY = process.env.PURPLEAIR_API_KEY; // API key stored in environment variables
    const fields = event.queryStringParameters.fields;
    const show_only = event.queryStringParameters.show_only;

    const url = `https://api.purpleair.com/v1/sensors?fields=${fields}&show_only=${show_only}`;

    try {
        const response = await fetch(url, {
            method: 'GET',
            headers: {
                'X-API-Key': API_KEY
            }
        });
        const data = await response.json();

        return {
            statusCode: 200,
            body: JSON.stringify(data),
            headers: {
                'Content-Type': 'application/json',
            },
        };
    } catch (error) {
        console.error('Error:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ error: 'Failed to fetch data from PurpleAir API' }),
        };
    }
};